public class JudgeScore {
 public static void main(String[] args) {
 
  /*
  PlEASE WRITEDOWN YOUR NAME AND MCGILL ID IN THIS SPACE
  Ines Moreno 260731240
  */ 
 
  //Declaring the variables for storing the judges scores.
  int judge1, judge2, judge3, judge4;
  judge1 = Integer.valueOf(args[0]);
  judge2 = Integer.valueOf(args[1]);
  judge3 = Integer.valueOf(args[2]);
  judge4 = Integer.valueOf(args[3]);
  
  //Your code Starts here
  // find which is the minimum score
 boolean min1 = (judge1<=judge2 && judge1<=judge3 && judge1<=judge4);
 boolean min2 = (judge2<=judge1 && judge2<=judge3 && judge2<=judge4);
 boolean min3 = (judge3<=judge2 && judge3<=judge1 && judge3<=judge4);
 boolean min4 = (judge4<=judge2 && judge4<=judge3 && judge4<=judge1);
  //find which is the maximum score
 boolean max1 = (judge1>=judge2 && judge1>=judge3 && judge1>=judge4);
 boolean max2 = (judge2>=judge1 && judge2>=judge3 && judge2>=judge4);
 boolean max3 = (judge3>=judge2 && judge3>=judge1 && judge3>=judge4);
 boolean max4 = (judge4>=judge2 && judge4>=judge3 && judge4>=judge1);
 //discard min and max and compute average
 if ((min1 && max2)|| (min2 && max1)){
   double av = (judge3+judge4)/2;
    System.out.println (av);
 } else if ((min1 && max3) || (min3 && max1)){
   double av = (judge2+judge4)/2.0;
    System.out.println (av);
 } else if ((min1 && max4) || (min4 && max1)){
   double av=(judge2+judge3)/2.0;
    System.out.println (av);
 } else if ((min2 && max3) || (min3 && max2)){
   double av=(judge1+judge4)/2.0;
    System.out.println (av);
 } else if ((min2 && max4)||(min4 && max2)){
   double av= (judge1+judge3)/2.0;
    System.out.println (av);
 } else {
   double av=(judge1+judge2)/2.0;
    System.out.println (av);
 }
                                 
    
  
  
  
  //Your code Ends here
  
 }
}
