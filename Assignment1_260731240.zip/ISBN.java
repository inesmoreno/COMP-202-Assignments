public class ISBN {

 public static void main(String[] args) {
 
  /*
  PlEASE WRITEDOWN YOUR NAME AND MCGILL ID IN THIS SPACE
  Ines Moreno 260731240
  */
 
  //Declaring the variable to represent the ISBN number
        int n = Integer.parseInt(args[0]);
        
        
        
     //Your code Starts here
     //Use division by 10 and remainders to separate and declare variables for each digit (d2,d3,d4,d5)
        int d2 = n%10;
        
        int rest = n/10;
        
        int d3 = rest%10;
       
        int rest2 = rest/10;
       
        int d4 = rest2%10;
       
        int d5 = rest2/10;
     
         
        // computations   
        int sum= 5*d5 + 4*d4 + 3*d3 + 2*d2;
        int r=sum%11;
        
        /*conditional statement to generate output; 3 cases:
         case 1= no remainder, d1=0
         case2 = remainder 10, d1=10
         case 3 = other remainder, d1=11-remainder  */
        
        if (r==0){
           System.out.println("0");
        } else if (11-r == 10){
            System.out.println("X");
        } else { 
            System.out.println(11-r);
        }

     //Your code Ends here
 }

}
